# Final capstone

The only file is a notebook that is divided in the following stages: 

* Download data:
    Only you have to execute the cells in order

* Preprocessing:
   All the cells that are not commented can be executed in order
  
* Training 
  Execute all cells in order
  